# fimatendimento
Interface para calcular a previsão de final de atendimento do CD.
